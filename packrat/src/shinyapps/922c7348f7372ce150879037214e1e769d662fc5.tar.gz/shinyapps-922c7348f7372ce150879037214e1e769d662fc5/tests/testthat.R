library(testthat)
library(shinyapps)

test_check("shinyapps")
